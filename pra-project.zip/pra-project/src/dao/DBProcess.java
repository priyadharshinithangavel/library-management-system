package dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Beanobjects;
import util.DbConnection;

public class DBProcess 
{
	Connection c = null;
	public DBProcess() throws ClassNotFoundException, SQLException 
	{
		DbConnection dbc = new DbConnection();
		c = dbc.getDBConn();
	}
	public void insert(Beanobjects s) throws SQLException
	{
			PreparedStatement p = c.prepareStatement("insert into Book_Tbll(ISBN,Book_title,Book_type,Author_code,Book_cost)values(?,?,?,?,?)");
			p.setString(1,s.getNum());
			p.setString(2,s.getName());
			p.setString(3,s.getBt());
			p.setInt(4,s.getCode());
			p.setInt(5,s.getBc());
			p.execute();
		System.out.println("The book details are Successfully inserted");
	}
	public void insertauthor(Beanobjects s1) throws SQLException
	{
			PreparedStatement p1 = c.prepareStatement("insert into Author_Tbll(Author_code,Author_name,Contact_no)values(?,?,?)");
			p1.setInt(1,s1.getCode());
			p1.setString(2,s1.getAn());
			p1.setInt(3,s1.getCon());
			p1.execute();
		System.out.println("The author details are Successfully inserted");
	}
//	public void view(Beanobjects s2) throws SQLException
//	{
//			PreparedStatement p2 = c.prepareStatement("select a.Author_name,b.Book_title from Author_Tbl a join Book_Tbl b on a.Author_code=b.Author_code where b.ISBN=?");
//			ResultSet rs=p2.executeQuery();
//			while(rs.next())
//            {    
//                	System.out.println("authorname"+rs.getString(1));
//                	System.out.println("title"+rs.getString(2));    
//            }
//		    System.out.println("Success...The Book details are printed");
//	} 
 }