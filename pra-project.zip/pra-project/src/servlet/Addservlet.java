package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Beanobjects;
import dao.DBProcess;
public class Addservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
     public Addservlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("add").equals("AddBooks")) {
	        System.out.println("add to customer details in database");
	        Beanobjects b=new Beanobjects();
	        b.setNum(req.getParameter("num"));
	        b.setName(req.getParameter("name"));
	        b.setBt(req.getParameter("bt"));
	        b.setCode(Integer.parseInt(req.getParameter("code")));
	        //System.out.println(req.getParameter("bc"));
	        b.setBc(Integer.parseInt(req.getParameter("bc")));
	        try {
	            DBProcess dbp = new DBProcess();
	            dbp.insert(b);
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        res.sendRedirect("Newfirst.html");
	    }
	}
	}

