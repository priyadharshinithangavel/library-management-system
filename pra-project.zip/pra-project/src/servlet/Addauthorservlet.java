package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Beanobjects;
import dao.DBProcess;
public class Addauthorservlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public Addauthorservlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("addauthor").equals("AddAuthor")) {
	        System.out.println("add author details in database");
	        Beanobjects b=new Beanobjects();
	        b.setCode(Integer.parseInt(req.getParameter("code")));
	        b.setAn(req.getParameter("an"));
	        b.setCon(Integer.parseInt(req.getParameter("con")));
	        try {
	            DBProcess dbp = new DBProcess();
	            dbp.insertauthor(b);
	            
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        res.sendRedirect("Newfirst.html");
	    }
	}

}
