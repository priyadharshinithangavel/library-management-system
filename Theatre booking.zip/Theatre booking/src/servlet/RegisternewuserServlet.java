package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Theatreobjects;
import dao.DBProcess;
public class RegisternewuserServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public RegisternewuserServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("submit12").equals("Submit"))
		{
			System.out.println();
			System.out.println(" ********####### USER PROCEE #######********");
	        System.out.println("Add New user details in database");
	        System.out.println("And the details are ..");
	        Theatreobjects b=new Theatreobjects();
	        b.setUname(req.getParameter("uname"));
	        System.out.println(req.getParameter("uname"));
	        b.setUadd(req.getParameter("uadd"));
	        System.out.println(req.getParameter("uadd"));
	        b.setUpho(req.getParameter("upho"));
	        System.out.println(req.getParameter("upho"));
	        b.setGen(req.getParameter("gen"));
	        System.out.println(req.getParameter("gen"));
	        b.setPwd(req.getParameter("pwd"));
	        System.out.println(req.getParameter("pwd"));
	        try {
	            DBProcess dbp = new DBProcess();
	            dbp.insertuser(b);
	            
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        res.sendRedirect("User.html");
	    }
		else if(req.getParameter("ccancel").equals("Cancel"))
		{
			res.sendRedirect("Registernewuser.html");
		}
	}

}