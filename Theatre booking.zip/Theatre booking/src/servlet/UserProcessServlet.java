package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Theatreobjects;
import dao.DBProcess;
public class UserProcessServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UserProcessServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("suubmit").equals("Login"))
		{
			System.out.println();
			System.out.println(" ********####### USER PROCEE #######********");
	        System.out.println("To check user details in database");
	        System.out.println("And the details are ..");
	        Theatreobjects b=new Theatreobjects();
	        b.setUname(req.getParameter("uname"));
	        System.out.println(req.getParameter("uname"));
	        b.setPwd(req.getParameter("pwd"));
	        System.out.println(req.getParameter("pwd"));
	        try {
	            DBProcess dbp = new DBProcess();
	            dbp.insertcheck(b);
	            
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        res.sendRedirect("userchoice.html");
	    }
		else if(req.getParameter("caancel").equals("Cancel"))
		{
			res.sendRedirect("User.html");
		}
	}

}
