package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Theatreobjects;
import dao.DBProcess;
public class AddtheatreServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AddtheatreServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("register1").equals("Register"))
		{
			System.out.println();
			System.out.println(" ********####### ADMIN PROCEE #######********");
	        System.out.println("Add new theatre details in database");
	        System.out.println("And the details are ..");
	        Theatreobjects b=new Theatreobjects();
	        b.setUname(req.getParameter("tname"));
	        System.out.println(req.getParameter("tname"));
	        b.setTadd(req.getParameter("tadd"));
	        System.out.println(req.getParameter("tadd"));
	        try {
	            DBProcess dbp = new DBProcess();
	            dbp.inserttheatre(b);
	            
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        res.sendRedirect("Admin.html");
	    }
		else if(req.getParameter("cancel1").equals("Cancel"))
		{
			res.sendRedirect("Addtheatre.html");
		}
	}

}
