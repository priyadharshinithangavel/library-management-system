package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
public class AdminLoginServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AdminLoginServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("loginn").equals("Login")) {
			if (req.getParameter("uname").equals(req.getParameter("pwd")))
			{
				res.sendRedirect("Admin.html");
			}
		}
		else if (req.getParameter("cancell1").equals("cancel")) 
		{
				res.sendRedirect("AdminLogin.html");
		}
	}

}
