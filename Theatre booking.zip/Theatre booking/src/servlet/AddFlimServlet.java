package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import bean.Theatreobjects;
import dao.DBProcess;
public class AddFlimServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public AddFlimServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("register2").equals("Register"))
		{
			System.out.println();
			System.out.println(" ********####### ADMIN PROCEE #######********");
	        System.out.println("Add new flim details in database");
	        System.out.println("And the details are ..");
	        Theatreobjects b=new Theatreobjects();
	        b.setFname(req.getParameter("fname"));
	        System.out.println(req.getParameter("fname"));
	        b.setFc(req.getParameter("fc"));
	        System.out.println(req.getParameter("fc"));
	        try {
	            DBProcess dbp = new DBProcess();
	            dbp.insertflim(b);
	            
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        res.sendRedirect("Admin.html");
	    }
		else if(req.getParameter("cancel2").equals("Cancel"))
		{
			res.sendRedirect("Addflim.html");
		}
	}

}
