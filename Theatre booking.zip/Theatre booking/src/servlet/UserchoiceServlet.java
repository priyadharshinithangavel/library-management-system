package servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import dao.DBProcess;

public class UserchoiceServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    public UserchoiceServlet() {
        super();
    }
	protected void doPost(HttpServletRequest req, HttpServletResponse res) throws ServletException, IOException {
		if (req.getParameter("subbmit").equals("Book Tickets")) 
		{
				res.sendRedirect("booktickets.html");
			
		}
		else if (req.getParameter("subbmmit").equals("Show Booking")) 
		{
			System.out.println();
			System.out.println(" ********####### USER PROCEE #######********");
		 try {
	            DBProcess dbp = new DBProcess();
	            dbp.insertdisplay();
	            res.sendRedirect("final1.html");
	        } catch (Exception ex) {
	            ex.printStackTrace();
	        }
	        
		}
	}

}
