package dao;

import java.beans.Statement;
import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
//import java.sql.ResultSet;
import java.sql.SQLException;

import bean.Theatreobjects;
import util.DbConnection;

public class DBProcess 
{
	Connection c = null;
	public DBProcess() throws ClassNotFoundException, SQLException 
	{
		DbConnection dbc = new DbConnection();
		c = dbc.getDBConn();
	}
	public void inserttheatre(Theatreobjects s) throws SQLException
	{
			PreparedStatement p = c.prepareStatement("insert into Theatredetails(Theatre_id,Theatre_name,Theatre_address)values(theatre_seq.nextval,?,?)");
			p.setString(1,s.getTname());
			p.setString(2,s.getTadd());
			p.execute();
			System.out.println("The Theatre details are Successfully inserted");
	}
	public void insertflim(Theatreobjects s1) throws SQLException
	{
			PreparedStatement p1 = c.prepareStatement("insert into Flimdetails(Flim_id,Flim_name,Flim_Certificate)values(flim_seq.nextval,?,?)");
			p1.setString(1,s1.getFname());
			p1.setString(2,s1.getFc());
			p1.execute();
			System.out.println("The flim details are Successfully inserted");
	}
	public void insertshow(Theatreobjects s2) throws SQLException
	{
			PreparedStatement p2 = c.prepareStatement("insert into Showdetails(Show_id,Theatre_name,Flim_name,Show_date,Show_time,sn1,sn2,sn3,sn4,sn5,sn6,sn7,sn8,sn9,sn10)values(show_seq.nextval,?,?,?,?,?,?,?,?,?,?,?,?,?,?)");
			p2.setString(1,s2.getTname());
			p2.setString(2,s2.getFname());
			p2.setString(3,s2.getDat());
			p2.setString(4,s2.getStime());
			p2.setString(5,"a");
			p2.setString(6,"a");
			p2.setString(7,"a");
			p2.setString(8,"a");
			p2.setString(9,"a");
			p2.setString(10,"a");
			p2.setString(11,"a");
			p2.setString(12,"a");
			p2.setString(13,"a");
			p2.setString(14,"a");
			p2.execute();
			System.out.println("The show details are Successfully inserted");
	}
	public void insertuser(Theatreobjects s3) throws SQLException
	{
			PreparedStatement p3 = c.prepareStatement("insert into Userdetails(User_id,User_name,U_address,U_phoneno,U_gender,U_password)values(user_seq.nextval,?,?,?,?,?)");
			p3.setString(1,s3.getUname());
			p3.setString(2,s3.getUadd());
			p3.setString(3,s3.getUpho());
			p3.setString(4,s3.getGen());
			p3.setString(5,s3.getPwd());
			p3.execute();
			System.out.println("The New user details are Successfully inserted");
	}
	public void insertcheck(Theatreobjects s4) throws SQLException
	{
			PreparedStatement p4 = c.prepareStatement("select User_name,U_password from Userdetails where User_name=? and U_password=?");
			p4.setString(1,s4.getUname());
			p4.setString(2,s4.getPwd());
			ResultSet rs=p4.executeQuery();
			while(rs.next())
            {    
                	System.out.println("User Name="+rs.getString(1));
                	System.out.println("Password ="+rs.getString(2));    
            }
		    System.out.println("User informations are correct...");
	} 
	public void insertbooking(Theatreobjects s5) throws SQLException
	{
			PreparedStatement p5 = c.prepareStatement("insert into Bookingdetails(User_id,User_name,Theatre_id,Theatre_name,Flim_id,Flim_name,Seat_name,Show_id)values(book1_seq.nextval,?,book2_seq.nextval,?,book3_seq.nextval,?,?,book4_seq.nextval)");
			p5.setString(1,s5.getUname());
			p5.setString(2,s5.getTname());
			p5.setString(3,s5.getFname());
			p5.setString(4,s5.getSno());
			p5.execute();
			System.out.println("The booking details are Successfully inserted");
	}
	public void insertdisplay() throws SQLException
	{
			PreparedStatement p6 = c.prepareStatement("select s.Theatre_name,b.Theatre_id,s.Flim_name,b.Flim_id,b.Show_id,s.Show_date,s.Show_time from Showdetails s join Bookingdetails b on b.Show_id=s.Show_id join Userdetails on u.User_id=b.User_id");
			ResultSet rs=p6.executeQuery();
			while(rs.next())
            {    
                	System.out.println("Theatre_name="+rs.getString(1));
                	System.out.println("Theatre_id="+rs.getString(2));
                	System.out.println("Flim_name ="+rs.getString(3));
                	System.out.println("Flim_id ="+rs.getString(4));
                	System.out.println("Show_id ="+rs.getString(5));
                	System.out.println("Show_date="+rs.getString(6));
                	System.out.println("Show_time ="+rs.getString(7));
            }
		    System.out.println("	THANK YOU    ");
	} 
 }